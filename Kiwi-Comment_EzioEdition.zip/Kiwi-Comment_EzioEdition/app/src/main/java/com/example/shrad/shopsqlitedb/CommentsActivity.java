package com.example.shrad.shopsqlitedb;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

/**
 * Created by Ezio on 24/09/2017.
 */

public class CommentsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_comments);
    }

    private void ShowInfo(int intType){
        String[] strInfos = null;
        ArrayAdapter<String>arrayAdapter = null;
        switch (intType){

        }
    }


}
